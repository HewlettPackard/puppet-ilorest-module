"""
Utilities to simplify communicating with iLO
"""
