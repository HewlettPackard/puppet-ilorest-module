# iLO 4 REST API Data Model
The data model documentation can be found
<a href="http://h22208.www2.hp.com/eginfolib/servers/docs/HPRestfultool/iLo4/data_model_reference.html" target="_blank"> here.
